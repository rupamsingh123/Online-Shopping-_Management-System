package rup.com.dao;

import java.util.List;

import rup.com.modul.Product;
import rup.com.modul.User;

public interface UserDao {
	public void createUser(User user);
	public void updateUser(User user);
	public void deleteUser(User user);
	 List<User> displayAlluser();
	}

