package rup.com.dao;


import java.util.List;
import java.util.Scanner;

//import javax.management.Query;
//import javax.persistence.TypedQuery;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import rup.com.modul.Product;
import rup.com.modul.User;
import rup.com.util.HibernateUtil;

public class UserDaoImp implements UserDao {
	Scanner scanner=new Scanner(System.in);
	private SessionFactory sessionFactory;
	
	public UserDaoImp() {
		this.sessionFactory=HibernateUtil.getSessionFactory();
	}
	//insert customer
	@Override
	public void createUser(User user) {
		Transaction transaction=null;
		try
		{
			Session session=sessionFactory.openSession();
			transaction=session.beginTransaction();
			System.out.println("Enter Name ");
			int id=1;
			String Name=scanner.nextLine();
			System.out.println("Enter Email");
			String Email=scanner.nextLine();
			System.out.println("Enter Address");
			String Address=scanner.nextLine();
			System.out.println("Enter password");
			String password=scanner.nextLine();
			
			User use = new User(id,Name,Email,password,Address);
			
			session.save(use);
			transaction.commit();
			System.out.println("Account created successfully");
		}
		catch(Exception e) {
			if (transaction != null) 
			  {
	             transaction.rollback();
			  }
			e.printStackTrace();

		}
		
	}
	//update userId
	public void updateUser(User user) {
			Transaction transaction = null;
		       try 
		       {    	   
		          Session session = sessionFactory.openSession();
		       
		           transaction = session.beginTransaction();
		           System.out.println("Enter User ID");
		           int Id=scanner.nextInt();
		           scanner.nextLine();
		           User use=session.get(User.class, Id);
		           
		           if(use !=null) {
		        	   System.out.println("Enter updated User name:");
		               String name = scanner.nextLine();
		               System.out.println("Enter updated password:");
		               String password=scanner.nextLine();
		               System.out.println("Enter updated Email:");
		               String email = scanner.nextLine();
		               System.out.println("Enter updated Address:");
		               String address = scanner.nextLine();
		               use.setUsername(name);
		               use.setPassword(password);
		               use.setEmail(email);
		               use.setAddress(address);
		               
		               session.update(use);
		               transaction.commit();
		               System.out.println("User updated successfully.");
		              
		           }
		           else {
		               System.out.println("User with ID "+Id + " not found.");
		           }
		    }
		       catch (Exception e) {
		           if (transaction != null) {
		               transaction.rollback();
		           }
		           e.printStackTrace();
		       }
		}
                    
		// Delete user
		
		public void deleteUser(Integer Id) {
			Transaction transaction = null;
		       try (Session session = sessionFactory.openSession()) {
		    	   System.out.println("Enter User Id");
		    	   int id=scanner.nextInt();
		    	   User user=session.get(User.class, id);
					session.beginTransaction();
					
					session.delete(user);//data will be deleted from DB
					session.getTransaction().commit();
					session.evict(user);//data will remove from session Cache
					System.out.println("Record deleted Successfully");
		       }
					
				
		        
		         catch (Exception e) {
		    	   System.out.println("Invalid User Id");
		           
		           }
		}
		     //       
		         public User findById(int userId) {
		        		try {
		        			Session session = sessionFactory.openSession();
		        			User user = session.get(User.class, userId);
		        			session.close();
		        			return user;
		        		} catch (Exception e) {
		        			System.err.println("Error finding user by ID: " + e.getMessage());
		        			return null;
		        		}
                       
		         
		       }
			@Override
			public void deleteUser(User user) {
				// TODO Auto-generated method stub
				
			}
			@Override
			public List<User> displayAlluser() {
				// TODO Auto-generated method stub
				return null;
			}
				
			
				
				
				
				
		
}

