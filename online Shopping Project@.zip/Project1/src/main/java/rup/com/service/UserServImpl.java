package rup.com.service;

import rup.com.dao.ProductDaoImp;
import rup.com.dao.UserDaoImp;
import rup.com.modul.Product;
import rup.com.modul.User;

public class UserServImpl implements UserServ {


	UserDaoImp udao = new UserDaoImp ();
	@Override
	public void createUser(User user) {
		udao.createUser(user);

	}

	@Override
	public void updateUser( User user) {
		udao.updateUser(user);
	}

	@Override
	public void deleteUser(int id) {
		udao.deleteUser(id);
	}
	public User findById(int userId) {
		return udao.findById(userId);
}

	@Override
	public void displyUser(User user) {
		// TODO Auto-generated method stub
		
	}

	
}
