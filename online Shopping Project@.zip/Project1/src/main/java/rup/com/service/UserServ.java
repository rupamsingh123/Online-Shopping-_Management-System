package rup.com.service;

import rup.com.modul.User;
import rup.com.modul.User;

public interface UserServ {
	public void createUser(User user);
	public void updateUser(User user);
	
	public void deleteUser(int id);  
	public void displyUser(User user);
	
}
