package rup.com.service;

import rup.com.dao.ProductDaoImp;
import rup.com.modul.Product;

public class ProductServiceImp implements ProductService{
     
	ProductDaoImp pdao = new ProductDaoImp ();
	@Override
	public void createProduct(Product product) {
		pdao.createProduct(product);
		
	}
	public void updateProduct(Product product) {
		pdao.updateProduct(product);
	}


	public void deleteProduct(Integer id) {
		pdao.deleteProduct(id);
	}

	public Product findById(int id) {
		return pdao.findById(id);
	}
	@Override
	public void deleteProduct(Product product) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void displyProduct(Product product) {
		// TODO Auto-generated method stub
		
	}


}
