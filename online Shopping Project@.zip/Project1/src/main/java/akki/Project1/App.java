package akki.Project1;

import java.util.Scanner;

import rup.com.modul.Product;
import rup.com.modul.User;
import rup.com.service.ProductServiceImp;
import rup.com.service.UserServImpl;


/**
 * Hello world!
 *
 */
/*public class App 
{
    public static void main( String[] args )
    {
    	System.out.println("project" );
    	
        ProductServiceImp pser = new ProductServiceImp();
        Product pmod= new Product();
        pser.createProduct(pmod);
        System.out.println("Record added");
        
     // Update User
        
        System.out.println("User updated successfully!");
    }
}
*/public class App {
    public static void main(String[] args) {

        System.out.println("======Project Start============");


        System.out.println("Choose project: 1. Product Service Project, 2. User Service Project 3. Exit");
        Scanner scannerProject = new Scanner(System.in);
        int project = scannerProject.nextInt();
        if (project == 1) {

            System.out.println("Welcome to Product Service project");
            Scanner scanner = new Scanner(System.in);
            ProductServiceImp pser = new ProductServiceImp();
            Product pmod = new Product();

            boolean exit = false;

            while (!exit) {
                System.out.println("Choose operation: 1. Create, 2. Read, 3. Update, 4. Delete, 5. Exit");
                int choice = scanner.nextInt();

                switch (choice) {
                    case 1:
                        pser.createProduct(pmod);
                        System.out.println("Record added");
                        break;
                    case 2:
                        System.out.println("Enter Product ID");
                        int Id = scanner.nextInt();
                        scanner.nextLine();
                        Product product = pser.findById(Id);
                        if (product != null) {
                            System.out.println(product);
                        } else {
                            System.out.println("product not found");
                        }
                        break;
                    case 3:
                        // Call update operation
                        pser.updateProduct(pmod);
                        break;
                    case 4:
                        // Call delete operation
                        System.out.println("Enter Product ID");
                        int id = scanner.nextInt();
                        scanner.nextLine();
                        pser.deleteProduct(id);
                        break;
                    case 5:
                        exit = true;
                        break;
                    default:
                        System.out.println("Invalid choice");
                }
            }



        } else if (project == 2) {

            System.out.println("User Service Project");
            Scanner scannerp = new Scanner(System.in);
            UserServImpl pser = new UserServImpl();
            User pmod = new User();

            boolean exit = false;

            while (!exit) {
                System.out.println("Choose operation: 1. Create, 2. Read, 3. Update, 4. Delete, 5. Exit");
                int choice = scannerp.nextInt();

                switch (choice) {
                    case 1:
                        pser.createUser(pmod);
                        System.out.println("Record added");
                        break;
                    case 2:
                        System.out.println("Enter user ID");
                        int Id = scannerp.nextInt();
                        scannerp.nextLine();
                        User user = pser.findById(Id);
                        if (user != null) {
                            System.out.println(user);
                        } else {
                            System.out.println("user not found");
                        }
                        break;
                    case 3:
                        // Call update operation
                        pser.updateUser(pmod);
                        break;
                    case 4:
                        // Call delete operation
                        System.out.println("Enter user ID");
                        int id = scannerp.nextInt();
                        scannerp.nextLine();
                        pser.deleteUser(id);
                        break;
                    case 5:
                        exit = true;
                        break;
                    default:
                        System.out.println("Invalid choice");
                }
            }





        } else if (project == 3) {

            System.out.println("Exit");

            System.exit(0);
        }


    }

    }



    